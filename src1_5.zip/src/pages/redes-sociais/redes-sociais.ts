import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-redes-sociais',
  templateUrl: 'redes-sociais.html'
})
export class RedesSociaisPage {

  constructor(public navCtrl: NavController) {
  }
  
}
