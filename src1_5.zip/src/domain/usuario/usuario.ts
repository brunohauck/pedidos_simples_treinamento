export class Usuario{

    constructor(
        public id: string,
        public nome: string,
        public email: string,
        public password: string,
        public status: string ){}
}