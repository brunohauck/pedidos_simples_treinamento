export class Restaurante{
    constructor(
        public id: string,
        public nome: string,
        public telefone: string,
        public imgurl: string
    ){}

}